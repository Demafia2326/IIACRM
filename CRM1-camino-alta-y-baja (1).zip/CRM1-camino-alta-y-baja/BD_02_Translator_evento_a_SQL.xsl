<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:output method="xml" indent="yes" encoding="UTF-8" cdata-section-elements="statement"/>
<xsl:template match="/"><query correlationId="{event/header/correlationId}">
<statement>WITH sistemas(crm) AS (
    SELECT 'CRM1' UNION ALL SELECT 'CRM2' UNION ALL SELECT 'CRM3'
)
SELECT
    s.crm,
    m.id_local,
    COALESCE(m.estado, 'DESCONOCIDO') AS estado_crm,
    m.fecha_alta,
    COALESCE(e.estado, 'NUEVA') AS estado_entrega,
    CASE
        WHEN s.crm = :origen THEN 'false'
        WHEN e.estado = 'CONFIRMED' THEN 'false'
        WHEN :operacion = 'ALTA' AND m.estado = 'ACTIVO' THEN 'false'
        WHEN :operacion = 'BAJA' AND m.estado IN ('AUSENTE', 'INACTIVO') THEN 'false'
        ELSE 'true'
    END AS pendiente
FROM sistemas s
LEFT JOIN clientes_sync m
    ON m.crm = s.crm AND m.clave = :clave_cliente
LEFT JOIN entregas_sync e
    ON e.destino = s.crm AND e.evento_id = :evento_id
ORDER BY s.crm</statement>
<parameters>
 <param name="clave_cliente"><xsl:value-of select="event/customer/@key"/></param>
 <param name="origen"><xsl:value-of select="event/header/source"/></param>
 <param name="operacion"><xsl:value-of select="event/header/operation"/></param>
 <param name="evento_id"><xsl:value-of select="event/header/eventId"/></param>
</parameters>
</query></xsl:template></xsl:stylesheet>