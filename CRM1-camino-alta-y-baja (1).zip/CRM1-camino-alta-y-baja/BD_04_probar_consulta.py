from pathlib import Path
from lxml import etree as E
import sqlite3, copy

HERE=Path(__file__).resolve().parent
def transform(name,node):
    return E.fromstring(E.tostring(E.XSLT(E.parse(str(HERE/name)))(node)))
def save(name,node):
    (HERE/name).write_bytes(E.tostring(node,pretty_print=True,encoding='UTF-8',xml_declaration=True))
def ejecutar_consulta(conn,request):
    parameters={p.get('name'):p.text for p in request.findall('parameters/param')}
    cursor=conn.execute(request.findtext('statement'),parameters)
    # El adaptador conserva la correlacion del sobre. No sale de una columna SQL.
    response=E.Element('queryResult',correlationId=request.get('correlationId'))
    columns=[d[0] for d in cursor.description]
    rows=cursor.fetchall();response.set('rows',str(len(rows)))
    for values in rows:
        row=E.SubElement(response,'row')
        for name,value in zip(columns,values):
            field=E.SubElement(row,name)
            if value is None:field.set('null','true')
            else:field.text=str(value)
    return response

def run():
    conn=sqlite3.connect(':memory:')
    conn.executescript("""
    CREATE TABLE clientes_sync (
       clave TEXT NOT NULL, crm TEXT NOT NULL, id_local TEXT,
       estado TEXT NOT NULL CHECK(estado IN ('ACTIVO','INACTIVO','AUSENTE')),
       fecha_alta TEXT, PRIMARY KEY (clave,crm));
    CREATE TABLE entregas_sync (
       evento_id TEXT NOT NULL, destino TEXT NOT NULL, estado TEXT NOT NULL,
       PRIMARY KEY(evento_id,destino));
    """)
    conn.executemany('INSERT INTO clientes_sync VALUES (?,?,?,?,?)',[
        ('CLI-25','CRM1','25','ACTIVO','2026-10-28T17:00:00+01:00'),
        ('CLI-25','CRM2',None,'AUSENTE',None),
        ('CLI-25','CRM3',None,'AUSENTE',None),
        ('CLI-90','CRM1','90','INACTIVO','2026-09-10T10:00:00+02:00'),
        ('CLI-90','CRM2','190','ACTIVO','2026-09-10T10:05:00+02:00'),
        ('CLI-90','CRM3','290','ACTIVO','2026-09-10T10:06:00+02:00')])
    for action,index in [('ALTA',1),('BAJA',2)]:
        source_name='03_CRM1_SPLITTER_TRADUCTOR_cliente_ALTA.xml' if action=='ALTA' else '04_CRM1_SPLITTER_TRADUCTOR_cliente_BAJA.xml'
        original=E.parse(str(HERE/source_name)).getroot()
        E.SubElement(original.find('header'),'correlationId').text=f'INTENTO-CRM1-{action}-{index:03d}'
        request=transform('BD_02_Translator_evento_a_SQL.xsl',original)
        response=ejecutar_consulta(conn,request)
        save(f'04{action}_TRADUCTOR_BD_salida_SQL_y_parametros.xml',request)
        save(f'04{action}_RESPUESTA_BD_para_ContentEnricher.xml',response)
        pair=E.Element('pair');pair.append(copy.deepcopy(original));pair.append(copy.deepcopy(response))
        enriched=transform('BD_03_ContentEnricher_original_mas_resultado.xsl',pair)
        enriched_name='05_CRM1_TRAS_CONSULTA_BD_cliente_ALTA_enriquecido.xml' if action=='ALTA' else '06_CRM1_TRAS_CONSULTA_BD_cliente_BAJA_enriquecido.xml'
        save(enriched_name,enriched)
        assert response.get('rows')=='3'
        assert enriched.findtext('header/operation')==action
        assert enriched.find('decision').get('action')=='APPLY'
        assert enriched.xpath("state/targets/target[@pending='true']/@system")==['CRM2','CRM3']
        if action=='BAJA':
            assert enriched.xpath("string(state/targets/target[@system='CRM2']/@id)")=='190'
            assert enriched.xpath("string(state/targets/target[@system='CRM3']/@id)")=='290'
        else:
            assert enriched.xpath("string(state/targets/target[@system='CRM2']/@id)")==''
        # El correlator descarta respuestas de otro intento.
        wrong=copy.deepcopy(pair);wrong.find('queryResult').set('correlationId','OTRO')
        try:transform('BD_03_ContentEnricher_original_mas_resultado.xsl',wrong)
        except E.XSLTApplyError:pass
        else:raise AssertionError('No se detecto correlacion erronea')
    # Un estado DESCONOCIDO no equivale a cliente ausente.
    conn.execute("DELETE FROM clientes_sync WHERE clave='CLI-25' AND crm='CRM2'")
    request=E.parse(str(HERE/'04ALTA_TRADUCTOR_BD_salida_SQL_y_parametros.xml')).getroot()
    response=ejecutar_consulta(conn,request)
    pair=E.Element('pair')
    original=E.parse(str(HERE/'03_CRM1_SPLITTER_TRADUCTOR_cliente_ALTA.xml')).getroot()
    E.SubElement(original.find('header'),'correlationId').text=request.get('correlationId')
    pair.append(original);pair.append(response)
    assert transform('BD_03_ContentEnricher_original_mas_resultado.xsl',pair).find('decision').get('action')=='REVIEW'
    conn.close()
    # Probar tambien las sentencias INSERT/DELETE del traductor de CRM3.
    remote=sqlite3.connect(':memory:')
    remote.execute('PRAGMA foreign_keys=ON')
    remote.executescript('''
        CREATE TABLE clientes(id INTEGER PRIMARY KEY, clave TEXT UNIQUE, nombre TEXT);
        CREATE TABLE direcciones(cliente_id INTEGER REFERENCES clientes(id) ON DELETE CASCADE,
            codigo TEXT, texto TEXT, UNIQUE(cliente_id,codigo));
        INSERT INTO clientes VALUES(290,'CLI-90','Ana');
        INSERT INTO direcciones VALUES(290,'D8','Calle Industria 14, Malaga');
    ''')
    for filename in ['09_CRM1_A_CRM3_TRADUCTOR_peticion_SQL_ALTA.xml','10_CRM1_A_CRM3_TRADUCTOR_peticion_SQL_BAJA.xml']:
        request=E.parse(str(HERE/filename)).getroot()
        with remote:
            for statement in request.findall('statement'):
                parameters={p.get('name'):p.text for p in statement.findall('parameters/param')}
                remote.execute(statement.text,parameters)
    assert remote.execute("SELECT nombre FROM clientes WHERE clave='CLI-25'").fetchone()==('Pepe',)
    assert remote.execute("SELECT count(*) FROM direcciones d JOIN clientes c ON c.id=d.cliente_id WHERE c.clave='CLI-25'").fetchone()==(2,)
    assert remote.execute("SELECT count(*) FROM clientes WHERE clave='CLI-90'").fetchone()==(0,)
    assert remote.execute("SELECT count(*) FROM direcciones WHERE cliente_id=290").fetchone()==(0,)
    remote.close()
    print('OK: SQL de consulta ejecutado para ALTA y BAJA; respuestas reales serializadas; enriquecimiento, IDs, correlacion, estado desconocido e INSERT/DELETE de CRM3 verificados.')
if __name__=='__main__':run()
