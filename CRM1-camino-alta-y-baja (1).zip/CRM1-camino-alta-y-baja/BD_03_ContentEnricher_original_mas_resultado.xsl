<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:output method="xml" indent="yes" encoding="UTF-8" cdata-section-elements="statement"/>
<xsl:template match="/">
<xsl:if test="pair/event/header/correlationId != pair/queryResult/@correlationId">
 <xsl:message terminate="yes">La respuesta no corresponde al original</xsl:message>
</xsl:if>
<event>
 <xsl:copy-of select="pair/event/header | pair/event/customer"/>
 <state><targets>
  <xsl:for-each select="pair/queryResult/row">
   <target system="{crm}" id="{id_local}" pending="{pendiente}"
           status="{estado_crm}" registeredAt="{fecha_alta}"/>
  </xsl:for-each>
 </targets></state>
 <decision><xsl:attribute name="action"><xsl:choose>
  <xsl:when test="pair/queryResult/row[estado_crm='DESCONOCIDO']
     or (pair/event/header/operation='BAJA' and pair/queryResult/row[pendiente='true' and not(string(id_local))])">REVIEW</xsl:when>
  <xsl:when test="not(pair/queryResult/row[pendiente='true'])">IGNORE</xsl:when>
  <xsl:when test="pair/queryResult/row[estado_entrega='PENDING' or estado_entrega='FAILED']">RETRY</xsl:when>
  <xsl:otherwise>APPLY</xsl:otherwise>
 </xsl:choose></xsl:attribute></decision>
</event></xsl:template></xsl:stylesheet>