-- Esquema auxiliar de ejemplo definido en BD_04_probar_consulta.py.
-- Enlazar los parametros, no sustituirlos concatenando texto.
WITH sistemas(crm) AS (
    SELECT 'CRM1' UNION ALL SELECT 'CRM2' UNION ALL SELECT 'CRM3'
)
SELECT
    s.crm,
    m.id_local,
    COALESCE(m.estado, 'DESCONOCIDO') AS estado_crm,
    m.fecha_alta,
    COALESCE(e.estado, 'NUEVA') AS estado_entrega,
    CASE
        WHEN s.crm = :origen THEN 'false'
        WHEN e.estado = 'CONFIRMED' THEN 'false'
        WHEN :operacion = 'ALTA' AND m.estado = 'ACTIVO' THEN 'false'
        WHEN :operacion = 'BAJA' AND m.estado IN ('AUSENTE', 'INACTIVO') THEN 'false'
        ELSE 'true'
    END AS pendiente
FROM sistemas s
LEFT JOIN clientes_sync m
    ON m.crm = s.crm AND m.clave = :clave_cliente
LEFT JOIN entregas_sync e
    ON e.destino = s.crm AND e.evento_id = :evento_id
ORDER BY s.crm;
